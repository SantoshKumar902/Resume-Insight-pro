import { Router, type IRouter } from "express";
import multer from "multer";
import { v4 as uuid } from "uuid";
import {
  GetResumeParams,
  DeleteResumeParams,
  CompareResumesBody,
} from "@workspace/api-zod";
import { extractPdfText, countWords } from "../lib/pdf.js";
import { analyzeResume } from "../lib/analyzer.js";
import {
  addResume,
  clearResumes,
  findResume,
  getResumes,
  removeResume,
  type StoredResume,
} from "../lib/session-store.js";

const router: IRouter = Router();

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 },
});

router.get("/resumes", (req, res) => {
  res.json(getResumes(req.session));
});

router.delete("/resumes", (req, res) => {
  clearResumes(req.session);
  res.status(204).send();
});

router.get("/resumes/summary", (req, res) => {
  const resumes = getResumes(req.session);
  const totalResumes = resumes.length;

  if (totalResumes === 0) {
    res.json({
      totalResumes: 0,
      averageOverall: 0,
      averageAts: 0,
      averageSkillsMatch: 0,
      topCandidate: null,
      levelBreakdown: [
        { level: "entry", count: 0 },
        { level: "mid", count: 0 },
        { level: "senior", count: 0 },
        { level: "expert", count: 0 },
      ],
    });
    return;
  }

  const avg = (key: keyof Pick<StoredResume, "overallScore" | "atsScore" | "skillsMatchScore">) =>
    Math.round(resumes.reduce((acc, r) => acc + r[key], 0) / totalResumes);

  const top = [...resumes].sort((a, b) => b.overallScore - a.overallScore)[0];

  const levels = ["entry", "mid", "senior", "expert"] as const;
  const levelBreakdown = levels.map((level) => ({
    level,
    count: resumes.filter((r) => r.experienceLevel === level).length,
  }));

  res.json({
    totalResumes,
    averageOverall: avg("overallScore"),
    averageAts: avg("atsScore"),
    averageSkillsMatch: avg("skillsMatchScore"),
    topCandidate: top ? top.candidateName ?? top.fileName : null,
    levelBreakdown,
  });
});

router.post("/resumes/analyze", upload.single("file"), async (req, res, next) => {
  try {
    const file = req.file;
    if (!file) {
      res.status(400).json({ error: "A PDF file is required (field name: file)." });
      return;
    }
    if (!file.mimetype.includes("pdf") && !file.originalname.toLowerCase().endsWith(".pdf")) {
      res.status(400).json({ error: "Only PDF files are supported." });
      return;
    }

    const jobDescription =
      typeof req.body.jobDescription === "string" && req.body.jobDescription.trim().length > 0
        ? req.body.jobDescription.trim()
        : null;
    const candidateName =
      typeof req.body.candidateName === "string" && req.body.candidateName.trim().length > 0
        ? req.body.candidateName.trim()
        : null;

    let resumeText: string;
    try {
      resumeText = await extractPdfText(file.buffer);
    } catch (err) {
      req.log.error({ err }, "PDF extraction failed");
      res.status(400).json({
        error: "Could not extract text from this PDF. It may be scanned, encrypted, or corrupted.",
      });
      return;
    }

    if (!resumeText || resumeText.length < 50) {
      res.status(400).json({
        error:
          "The PDF appears to contain no extractable text. If it is a scanned document, please upload a text-based PDF.",
      });
      return;
    }

    const analysis = await analyzeResume({
      resumeText,
      jobDescription,
      candidateName,
      fileName: file.originalname,
    });

    const stored: StoredResume = {
      id: uuid(),
      fileName: file.originalname,
      candidateName,
      createdAt: new Date().toISOString(),
      jobDescription,
      textPreview: resumeText.slice(0, 1200),
      wordCount: countWords(resumeText),
      ...analysis,
    };

    addResume(req.session, stored);
    res.json(stored);
  } catch (err) {
    next(err);
  }
});

router.get("/resumes/:id", (req, res) => {
  const { id } = GetResumeParams.parse(req.params);
  const resume = findResume(req.session, id);
  if (!resume) {
    res.status(404).json({ error: "Resume not found in this session." });
    return;
  }
  res.json(resume);
});

router.delete("/resumes/:id", (req, res) => {
  const { id } = DeleteResumeParams.parse(req.params);
  const removed = removeResume(req.session, id);
  if (!removed) {
    res.status(404).json({ error: "Resume not found in this session." });
    return;
  }
  res.status(204).send();
});

router.post("/resumes/compare", (req, res) => {
  const { ids } = CompareResumesBody.parse(req.body);
  const resumes = ids
    .map((id) => findResume(req.session, id))
    .filter((r): r is StoredResume => Boolean(r));

  if (resumes.length < 2) {
    res.status(400).json({ error: "At least two valid resumes are required for comparison." });
    return;
  }

  const rows = resumes.map((r) => ({
    id: r.id,
    label: r.candidateName ?? r.fileName,
    overallScore: r.overallScore,
    atsScore: r.atsScore,
    skillsMatchScore: r.skillsMatchScore,
    experienceScore: r.experienceScore,
    experienceLevel: r.experienceLevel,
    matchedSkills: r.matchedSkills,
    missingSkills: r.missingSkills,
  }));

  const skillSets = resumes.map((r) => new Set(r.matchedSkills.map((s) => s.toLowerCase())));
  const allSkills = new Set<string>();
  resumes.forEach((r) => r.matchedSkills.forEach((s) => allSkills.add(s)));

  const sharedSkills: string[] = [];
  for (const skill of allSkills) {
    const lower = skill.toLowerCase();
    if (skillSets.every((set) => set.has(lower))) {
      if (!sharedSkills.some((s) => s.toLowerCase() === lower)) {
        sharedSkills.push(skill);
      }
    }
  }

  const uniqueSkills = resumes.map((r, i) => {
    const others = skillSets.filter((_, j) => j !== i);
    const unique = r.matchedSkills.filter(
      (s) => !others.some((set) => set.has(s.toLowerCase())),
    );
    return { id: r.id, skills: unique };
  });

  const winner = [...resumes].sort((a, b) => b.overallScore - a.overallScore)[0];

  res.json({
    rows,
    sharedSkills,
    uniqueSkills,
    winnerId: winner ? winner.id : null,
  });
});

export default router;
