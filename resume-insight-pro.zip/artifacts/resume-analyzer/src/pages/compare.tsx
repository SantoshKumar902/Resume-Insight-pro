import { useState } from "react";
import { useListResumes, useCompareResumes } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, CartesianGrid } from "recharts";
import { Trophy, Check, X as XIcon } from "lucide-react";

export default function ComparePage() {
  const { data: resumes, isLoading } = useListResumes();
  const compareMutation = useCompareResumes();
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  const handleToggle = (id: string) => {
    setSelectedIds(prev => 
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  const handleCompare = () => {
    if (selectedIds.length < 2) return;
    compareMutation.mutate({ data: { ids: selectedIds } });
  };

  if (isLoading) {
    return <div className="p-8">Loading resumes...</div>;
  }

  const comparison = compareMutation.data;

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Compare Candidates</h1>
        <p className="text-muted-foreground mt-1">Select 2 or more resumes to see them side-by-side.</p>
      </div>

      {!comparison && (
        <Card>
          <CardContent className="p-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 mb-6">
              {resumes?.map(resume => (
                <div 
                  key={resume.id}
                  className={`border rounded-lg p-4 flex items-start gap-3 cursor-pointer transition-colors ${selectedIds.includes(resume.id) ? 'border-primary bg-primary/5' : 'hover:border-primary/50'}`}
                  onClick={() => handleToggle(resume.id)}
                >
                  <Checkbox checked={selectedIds.includes(resume.id)} onCheckedChange={() => handleToggle(resume.id)} />
                  <div>
                    <p className="font-medium">{resume.candidateName || resume.fileName}</p>
                    <p className="text-xs text-muted-foreground mt-1 capitalize">{resume.experienceLevel} • {Math.round(resume.overallScore)}/100</p>
                  </div>
                </div>
              ))}
            </div>
            <Button 
              onClick={handleCompare} 
              disabled={selectedIds.length < 2 || compareMutation.isPending}
              className="w-full sm:w-auto"
            >
              Compare Selected ({selectedIds.length})
            </Button>
          </CardContent>
        </Card>
      )}

      {comparison && (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold tracking-tight">Comparison Results</h2>
            <Button variant="outline" onClick={() => compareMutation.reset()}>New Comparison</Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {comparison.rows.map((row) => (
              <Card key={row.id} className={row.id === comparison.winnerId ? 'border-primary ring-1 ring-primary' : ''}>
                <CardHeader className="pb-4">
                  {row.id === comparison.winnerId && (
                    <div className="text-primary flex items-center gap-1.5 text-sm font-semibold mb-2 uppercase tracking-wider">
                      <Trophy className="w-4 h-4" /> Top Match
                    </div>
                  )}
                  <CardTitle>{row.label}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">Overall</p>
                      <p className="text-2xl font-bold">{Math.round(row.overallScore)}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">Skills Match</p>
                      <p className="text-2xl font-bold">{Math.round(row.skillsMatchScore)}</p>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <p className="text-sm font-medium">Top Skills</p>
                    <div className="flex flex-wrap gap-1.5">
                      {row.matchedSkills.slice(0, 5).map((s, i) => (
                        <span key={i} className="text-xs px-2 py-1 bg-primary/10 text-primary rounded">{s}</span>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Score Breakdown</CardTitle>
            </CardHeader>
            <CardContent className="h-[400px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={[
                  { category: "Overall", ...comparison.rows.reduce((acc, r) => ({...acc, [r.label]: Math.round(r.overallScore)}), {}) },
                  { category: "ATS", ...comparison.rows.reduce((acc, r) => ({...acc, [r.label]: Math.round(r.atsScore)}), {}) },
                  { category: "Skills", ...comparison.rows.reduce((acc, r) => ({...acc, [r.label]: Math.round(r.skillsMatchScore)}), {}) },
                  { category: "Experience", ...comparison.rows.reduce((acc, r) => ({...acc, [r.label]: Math.round(r.experienceScore)}), {}) }
                ]} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                  <XAxis dataKey="category" axisLine={false} tickLine={false} tick={{fill: "hsl(var(--muted-foreground))"}} />
                  <YAxis axisLine={false} tickLine={false} tick={{fill: "hsl(var(--muted-foreground))"}} domain={[0, 100]} />
                  <Tooltip 
                    cursor={{fill: "hsl(var(--muted)/0.5)"}}
                    contentStyle={{backgroundColor: "hsl(var(--popover))", border: "1px solid hsl(var(--border))", borderRadius: "8px"}}
                  />
                  <Legend />
                  {comparison.rows.map((r, i) => (
                    <Bar key={r.id} dataKey={r.label} fill={i === 0 ? "hsl(var(--primary))" : "hsl(var(--chart-2))"} radius={[4, 4, 0, 0]} />
                  ))}
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
