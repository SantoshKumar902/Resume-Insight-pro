import { useState } from "react";
import { useGetResumesSummary, useListResumes, useClearResumes, useDeleteResume } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { FileText, Trash2, ArrowRight, Activity, Target, Award, Plus } from "lucide-react";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { getListResumesQueryKey, getGetResumesSummaryQueryKey } from "@workspace/api-client-react";

export default function Dashboard() {
  const { data: summary, isLoading: loadingSummary } = useGetResumesSummary();
  const { data: resumes, isLoading: loadingResumes } = useListResumes();
  const deleteResume = useDeleteResume();
  const clearResumes = useClearResumes();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const handleDelete = (id: string) => {
    deleteResume.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListResumesQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetResumesSummaryQueryKey() });
        toast({ title: "Resume deleted" });
      }
    });
  };

  const handleClear = () => {
    clearResumes.mutate(undefined, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListResumesQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetResumesSummaryQueryKey() });
        toast({ title: "All resumes cleared" });
      }
    });
  };

  if (loadingSummary || loadingResumes) {
    return <div className="p-8">Loading dashboard...</div>;
  }

  const hasResumes = resumes && resumes.length > 0;

  if (!hasResumes) {
    return (
      <div className="p-8 h-full flex flex-col items-center justify-center text-center max-w-md mx-auto">
        <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-6">
          <FileText className="text-primary w-8 h-8" />
        </div>
        <h2 className="text-2xl font-semibold mb-2">No resumes analyzed yet</h2>
        <p className="text-muted-foreground mb-8">
          Upload a resume and job description to get instant AI-powered scoring, skill matching, and feedback.
        </p>
        <Link href="/upload">
          <Button size="lg" className="gap-2">
            <Plus className="w-4 h-4" />
            Upload First Resume
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Overview</h1>
          <p className="text-muted-foreground mt-1">Aggregate statistics across {summary?.totalResumes || 0} candidates</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" onClick={handleClear} disabled={clearResumes.isPending}>
            Clear All
          </Button>
          <Link href="/upload">
            <Button className="gap-2">
              <Plus className="w-4 h-4" />
              Upload Resume
            </Button>
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <MetricCard title="Total Candidates" value={summary?.totalResumes || 0} icon={FileText} />
        <MetricCard title="Avg Overall Score" value={Math.round(summary?.averageOverall || 0)} icon={Activity} suffix="/100" />
        <MetricCard title="Avg ATS Match" value={Math.round(summary?.averageAts || 0)} icon={Target} suffix="/100" />
        <MetricCard title="Avg Skills Match" value={Math.round(summary?.averageSkillsMatch || 0)} icon={Award} suffix="/100" />
      </div>

      <div className="space-y-4">
        <h2 className="text-xl font-semibold tracking-tight">Recent Analyses</h2>
        <div className="border rounded-lg bg-card text-card-foreground shadow-sm overflow-hidden">
          <div className="divide-y divide-border">
            {resumes?.map((resume) => (
              <div key={resume.id} className="p-4 flex items-center justify-between hover:bg-muted/30 transition-colors">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-semibold">
                    {Math.round(resume.overallScore)}
                  </div>
                  <div>
                    <h4 className="font-medium text-foreground">{resume.candidateName || resume.fileName}</h4>
                    <p className="text-sm text-muted-foreground flex items-center gap-2">
                      {format(new Date(resume.createdAt), "MMM d, yyyy")}
                      <span>•</span>
                      {resume.experienceLevel} level
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Link href={`/analysis/${resume.id}`}>
                    <Button variant="secondary" size="sm" className="gap-1">
                      View Analysis <ArrowRight className="w-3 h-3" />
                    </Button>
                  </Link>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="text-muted-foreground hover:text-destructive"
                    onClick={() => handleDelete(resume.id)}
                    disabled={deleteResume.isPending}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function MetricCard({ title, value, icon: Icon, suffix = "" }: { title: string; value: number; icon: any; suffix?: string }) {
  return (
    <Card>
      <CardContent className="p-6 flex flex-col justify-between h-full">
        <div className="flex items-center justify-between mb-4">
          <p className="text-sm font-medium text-muted-foreground">{title}</p>
          <Icon className="w-4 h-4 text-muted-foreground" />
        </div>
        <div className="flex items-baseline gap-1">
          <h3 className="text-3xl font-bold tracking-tighter">{value}</h3>
          <span className="text-muted-foreground font-medium">{suffix}</span>
        </div>
      </CardContent>
    </Card>
  );
}
