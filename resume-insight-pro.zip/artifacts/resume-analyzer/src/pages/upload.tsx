import { useState, useCallback, useEffect } from "react";
import { useLocation } from "wouter";
import { useAnalyzeResume } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { getListResumesQueryKey, getGetResumesSummaryQueryKey } from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { UploadCloud, File, X, CheckCircle2, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

export default function UploadPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const analyzeResume = useAnalyzeResume();

  const [file, setFile] = useState<File | null>(null);
  const [candidateName, setCandidateName] = useState("");
  const [jobDescription, setJobDescription] = useState("");
  const [isDragging, setIsDragging] = useState(false);
  
  // Fake loading progress
  const [loadingStep, setLoadingStep] = useState(0);

  const steps = [
    "Extracting text from document...",
    "Analyzing semantic structure...",
    "Running AI scoring models...",
    "Generating actionable insights..."
  ];

  useEffect(() => {
    if (analyzeResume.isPending) {
      const interval = setInterval(() => {
        setLoadingStep((s) => Math.min(s + 1, steps.length - 1));
      }, 2000);
      return () => clearInterval(interval);
    }
    return undefined;
  }, [analyzeResume.isPending]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const droppedFile = e.dataTransfer.files[0];
      if (droppedFile.type === "application/pdf") {
        setFile(droppedFile);
      } else {
        toast({ title: "Invalid file type", description: "Please upload a PDF file.", variant: "destructive" });
      }
    }
  }, [toast]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setFile(e.target.files[0]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) return;

    analyzeResume.mutate({
      data: {
        file,
        candidateName: candidateName || undefined,
        jobDescription: jobDescription || undefined
      }
    }, {
      onSuccess: (data) => {
        queryClient.invalidateQueries({ queryKey: getListResumesQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetResumesSummaryQueryKey() });
        toast({ title: "Analysis complete" });
        setLocation(`/analysis/${data.id}`);
      },
      onError: (err) => {
        toast({ title: "Analysis failed", description: err.message, variant: "destructive" });
      }
    });
  };

  if (analyzeResume.isPending) {
    return (
      <div className="p-8 max-w-2xl mx-auto h-full flex flex-col items-center justify-center text-center">
        <div className="w-20 h-20 relative mb-8">
          <div className="absolute inset-0 border-4 border-primary/20 rounded-full"></div>
          <div className="absolute inset-0 border-4 border-primary rounded-full border-t-transparent animate-spin"></div>
        </div>
        <h2 className="text-2xl font-bold tracking-tight mb-2">Analyzing Resume</h2>
        <p className="text-muted-foreground mb-8 max-w-sm">
          Our AI is evaluating the candidate against the job requirements. This usually takes 5-15 seconds.
        </p>
        
        <div className="w-full max-w-md space-y-4 text-left">
          {steps.map((step, idx) => (
            <div key={idx} className={cn(
              "flex items-center gap-3 p-3 rounded-lg border transition-colors",
              idx === loadingStep ? "border-primary bg-primary/5 text-primary" :
              idx < loadingStep ? "border-muted bg-muted/30 text-muted-foreground" :
              "border-transparent text-muted-foreground/40"
            )}>
              {idx < loadingStep ? <CheckCircle2 className="w-5 h-5" /> :
               idx === loadingStep ? <Loader2 className="w-5 h-5 animate-spin" /> :
               <div className="w-5 h-5 rounded-full border-2 border-current opacity-20"></div>}
              <span className="font-medium text-sm">{step}</span>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight">New Analysis</h1>
        <p className="text-muted-foreground mt-1">Upload a candidate's resume and provide job context.</p>
      </div>

      <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Resume Document</CardTitle>
              <CardDescription>Upload a PDF format resume.</CardDescription>
            </CardHeader>
            <CardContent>
              {!file ? (
                <div 
                  className={cn(
                    "border-2 border-dashed rounded-xl p-10 flex flex-col items-center justify-center text-center transition-colors cursor-pointer",
                    isDragging ? "border-primary bg-primary/5" : "border-border hover:border-primary/50 hover:bg-muted/50"
                  )}
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                  onClick={() => document.getElementById('file-upload')?.click()}
                >
                  <input id="file-upload" type="file" accept=".pdf" className="hidden" onChange={handleFileChange} />
                  <UploadCloud className="w-10 h-10 text-muted-foreground mb-4" />
                  <h3 className="font-medium text-lg mb-1">Click or drag file here</h3>
                  <p className="text-sm text-muted-foreground">PDF only, up to 5MB</p>
                </div>
              ) : (
                <div className="border rounded-xl p-6 flex items-center justify-between bg-muted/30">
                  <div className="flex items-center gap-4">
                    <div className="p-3 bg-primary/10 text-primary rounded-lg">
                      <File className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="font-medium truncate max-w-[200px]">{file.name}</p>
                      <p className="text-xs text-muted-foreground">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon" type="button" onClick={() => setFile(null)}>
                    <X className="w-4 h-4 text-muted-foreground" />
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Candidate Info <span className="text-muted-foreground font-normal text-sm">(Optional)</span></CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <Label htmlFor="name">Full Name</Label>
                <Input 
                  id="name" 
                  placeholder="e.g. Jane Doe" 
                  value={candidateName}
                  onChange={(e) => setCandidateName(e.target.value)}
                />
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="h-full flex flex-col">
            <CardHeader>
              <CardTitle>Job Description <span className="text-muted-foreground font-normal text-sm">(Optional but recommended)</span></CardTitle>
              <CardDescription>We'll match the resume skills against these requirements.</CardDescription>
            </CardHeader>
            <CardContent className="flex-1 flex flex-col">
              <Textarea 
                placeholder="Paste the job description or required skills here..."
                className="flex-1 min-h-[300px] resize-none"
                value={jobDescription}
                onChange={(e) => setJobDescription(e.target.value)}
              />
            </CardContent>
          </Card>
        </div>

        <div className="md:col-span-2 flex justify-end">
          <Button type="submit" size="lg" className="w-full md:w-auto px-8" disabled={!file || analyzeResume.isPending}>
            Analyze Candidate
          </Button>
        </div>
      </form>
    </div>
  );
}
