import { useState } from "react";
import { useGetResume } from "@workspace/api-client-react";
import { getGetResumeQueryKey } from "@workspace/api-client-react";
import { useParams } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from "recharts";

function ScoreRing({ score, label }: { score: number, label: string }) {
  const color = score >= 85 ? "text-primary" : score >= 70 ? "text-green-500" : score >= 50 ? "text-amber-500" : "text-destructive";
  const strokeColor = score >= 85 ? "stroke-primary" : score >= 70 ? "stroke-green-500" : score >= 50 ? "stroke-amber-500" : "stroke-destructive";
  
  const radius = 38;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (score / 100) * circumference;

  return (
    <div className="flex flex-col items-center justify-center">
      <div className="relative w-24 h-24 flex items-center justify-center">
        <svg className="transform -rotate-90 w-24 h-24">
          <circle cx="48" cy="48" r="38" stroke="currentColor" strokeWidth="8" fill="transparent" className="text-muted opacity-20" />
          <circle 
            cx="48" cy="48" r="38" 
            stroke="currentColor" 
            strokeWidth="8" 
            fill="transparent" 
            strokeDasharray={circumference} 
            strokeDashoffset={strokeDashoffset} 
            className={`transition-all duration-1000 ease-out ${strokeColor}`} 
          />
        </svg>
        <span className={`absolute text-xl font-bold ${color}`}>{score}</span>
      </div>
      <span className="text-sm font-medium mt-2 text-muted-foreground">{label}</span>
    </div>
  );
}

export default function AnalysisPage() {
  const params = useParams();
  const id = params.id;
  const { data: resume, isLoading } = useGetResume(id || "", { query: { enabled: !!id, queryKey: getGetResumeQueryKey(id || "") } });

  if (isLoading) {
    return <div className="p-8">Loading analysis...</div>;
  }

  if (!resume) {
    return <div className="p-8">Analysis not found.</div>;
  }

  const atsData = [
    { name: "Formatting", score: resume.atsBreakdown.formatting },
    { name: "Keywords", score: resume.atsBreakdown.keywords },
    { name: "Readability", score: resume.atsBreakdown.readability },
    { name: "Sections", score: resume.atsBreakdown.sectionCoverage },
    { name: "Contact", score: resume.atsBreakdown.contactInfo },
  ];

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">{resume.candidateName || resume.fileName}</h1>
        <p className="text-muted-foreground mt-1 capitalize">{resume.experienceLevel} Level • {resume.yearsOfExperience} Years Experience</p>
      </div>

      {/* Score Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6 flex items-center justify-center">
            <ScoreRing score={Math.round(resume.overallScore)} label="Overall Score" />
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 flex items-center justify-center">
            <ScoreRing score={Math.round(resume.atsScore)} label="ATS Compatibility" />
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 flex items-center justify-center">
            <ScoreRing score={Math.round(resume.skillsMatchScore)} label="Skills Match" />
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 flex items-center justify-center">
            <ScoreRing score={Math.round(resume.experienceScore)} label="Experience Strength" />
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-8">
          {/* Summary */}
          <Card>
            <CardHeader>
              <CardTitle>AI Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed">{resume.summary}</p>
            </CardContent>
          </Card>

          {/* Strengths & Weaknesses */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-green-500 text-base">Key Strengths</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {resume.strengths.map((s, i) => (
                    <li key={i} className="flex gap-2 text-sm text-muted-foreground">
                      <span className="text-green-500 mt-0.5">•</span> {s}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="text-destructive text-base">Areas for Improvement</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {resume.weaknesses.map((w, i) => (
                    <li key={i} className="flex gap-2 text-sm text-muted-foreground">
                      <span className="text-destructive mt-0.5">•</span> {w}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>

          {/* Suggestions */}
          <Card>
            <CardHeader>
              <CardTitle>Improvement Suggestions</CardTitle>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                {resume.improvements.map((imp, idx) => (
                  <AccordionItem key={idx} value={`item-${idx}`}>
                    <AccordionTrigger className="hover:no-underline text-left">
                      <div className="flex items-center gap-3">
                        <Badge variant={imp.priority === "high" ? "destructive" : imp.priority === "medium" ? "default" : "secondary"}>
                          {imp.priority}
                        </Badge>
                        <span className="font-medium">{imp.title}</span>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="text-muted-foreground space-y-4 pt-2">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="p-3 bg-destructive/5 border border-destructive/20 rounded-md">
                          <p className="text-xs font-semibold text-destructive mb-1 uppercase tracking-wider">Current</p>
                          <p className="text-sm">"{imp.current}"</p>
                        </div>
                        <div className="p-3 bg-green-500/5 border border-green-500/20 rounded-md">
                          <p className="text-xs font-semibold text-green-500 mb-1 uppercase tracking-wider">Suggested</p>
                          <p className="text-sm">"{imp.suggested}"</p>
                        </div>
                      </div>
                      <p className="text-sm"><strong className="text-foreground">Why:</strong> {imp.rationale}</p>
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-8">
          {/* ATS Breakdown */}
          <Card>
            <CardHeader>
              <CardTitle>ATS Breakdown</CardTitle>
            </CardHeader>
            <CardContent className="h-[250px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={atsData} layout="vertical" margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                  <XAxis type="number" domain={[0, 100]} hide />
                  <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} tick={{fill: "hsl(var(--muted-foreground))", fontSize: 12}} width={80} />
                  <Tooltip 
                    cursor={{fill: "hsl(var(--muted)/0.5)"}}
                    contentStyle={{backgroundColor: "hsl(var(--popover))", border: "1px solid hsl(var(--border))", borderRadius: "8px"}}
                  />
                  <Bar dataKey="score" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} barSize={20} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Skills */}
          <Card>
            <CardHeader>
              <CardTitle>Matched Skills</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {resume.matchedSkills.map((skill, i) => (
                  <Badge key={i} variant="secondary" className="bg-primary/10 text-primary hover:bg-primary/20 border-transparent">
                    {skill}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>

          {resume.missingSkills && resume.missingSkills.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Missing Skills</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {resume.missingSkills.map((skill, i) => (
                    <Badge key={i} variant="outline" className="text-muted-foreground border-dashed">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
