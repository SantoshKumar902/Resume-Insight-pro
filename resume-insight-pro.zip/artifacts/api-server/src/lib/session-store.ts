import "express-session";

export interface StoredResume {
  id: string;
  fileName: string;
  candidateName: string | null;
  createdAt: string;
  jobDescription: string | null;
  textPreview: string;
  wordCount: number;
  overallScore: number;
  atsScore: number;
  skillsMatchScore: number;
  experienceScore: number;
  experienceLevel: "entry" | "mid" | "senior" | "expert";
  yearsOfExperience: number;
  summary: string;
  strengths: string[];
  weaknesses: string[];
  matchedSkills: string[];
  missingSkills: string[];
  skillCategories: { name: string; count: number; skills: string[] }[];
  keywordHits: { keyword: string; matched: boolean; occurrences: number }[];
  improvements: {
    title: string;
    category: string;
    priority: "high" | "medium" | "low";
    current: string;
    suggested: string;
    rationale: string;
  }[];
  atsBreakdown: {
    formatting: number;
    keywords: number;
    readability: number;
    sectionCoverage: number;
    contactInfo: number;
  };
}

declare module "express-session" {
  interface SessionData {
    resumes?: StoredResume[];
  }
}

export function getResumes(session: import("express-session").Session & Partial<import("express-session").SessionData>): StoredResume[] {
  if (!session.resumes) {
    session.resumes = [];
  }
  return session.resumes;
}

export function addResume(
  session: import("express-session").Session & Partial<import("express-session").SessionData>,
  resume: StoredResume,
): void {
  const resumes = getResumes(session);
  resumes.unshift(resume);
  if (resumes.length > 25) {
    resumes.length = 25;
  }
}

export function findResume(
  session: import("express-session").Session & Partial<import("express-session").SessionData>,
  id: string,
): StoredResume | undefined {
  return getResumes(session).find((r) => r.id === id);
}

export function removeResume(
  session: import("express-session").Session & Partial<import("express-session").SessionData>,
  id: string,
): boolean {
  const resumes = getResumes(session);
  const idx = resumes.findIndex((r) => r.id === id);
  if (idx === -1) return false;
  resumes.splice(idx, 1);
  return true;
}

export function clearResumes(
  session: import("express-session").Session & Partial<import("express-session").SessionData>,
): void {
  session.resumes = [];
}
