import { ai, Type } from "@workspace/integrations-gemini-ai";
import type { StoredResume } from "./session-store.js";

type AiAnalysis = Omit<
  StoredResume,
  "id" | "fileName" | "candidateName" | "createdAt" | "jobDescription" | "textPreview" | "wordCount"
>;

const responseSchema = {
  type: Type.OBJECT,
  properties: {
    overallScore: { type: Type.INTEGER },
    atsScore: { type: Type.INTEGER },
    skillsMatchScore: { type: Type.INTEGER },
    experienceScore: { type: Type.INTEGER },
    experienceLevel: {
      type: Type.STRING,
      enum: ["entry", "mid", "senior", "expert"],
    },
    yearsOfExperience: { type: Type.NUMBER },
    summary: { type: Type.STRING },
    strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
    weaknesses: { type: Type.ARRAY, items: { type: Type.STRING } },
    matchedSkills: { type: Type.ARRAY, items: { type: Type.STRING } },
    missingSkills: { type: Type.ARRAY, items: { type: Type.STRING } },
    skillCategories: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          count: { type: Type.INTEGER },
          skills: { type: Type.ARRAY, items: { type: Type.STRING } },
        },
        required: ["name", "count", "skills"],
      },
    },
    keywordHits: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          keyword: { type: Type.STRING },
          matched: { type: Type.BOOLEAN },
          occurrences: { type: Type.INTEGER },
        },
        required: ["keyword", "matched", "occurrences"],
      },
    },
    improvements: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          category: { type: Type.STRING },
          priority: {
            type: Type.STRING,
            enum: ["high", "medium", "low"],
          },
          current: { type: Type.STRING },
          suggested: { type: Type.STRING },
          rationale: { type: Type.STRING },
        },
        required: ["title", "category", "priority", "current", "suggested", "rationale"],
      },
    },
    atsBreakdown: {
      type: Type.OBJECT,
      properties: {
        formatting: { type: Type.INTEGER },
        keywords: { type: Type.INTEGER },
        readability: { type: Type.INTEGER },
        sectionCoverage: { type: Type.INTEGER },
        contactInfo: { type: Type.INTEGER },
      },
      required: ["formatting", "keywords", "readability", "sectionCoverage", "contactInfo"],
    },
  },
  required: [
    "overallScore",
    "atsScore",
    "skillsMatchScore",
    "experienceScore",
    "experienceLevel",
    "yearsOfExperience",
    "summary",
    "strengths",
    "weaknesses",
    "matchedSkills",
    "missingSkills",
    "skillCategories",
    "keywordHits",
    "improvements",
    "atsBreakdown",
  ],
};

const SYSTEM_INSTRUCTION = `You are an expert technical recruiter and ATS (Applicant Tracking System) specialist who scores resumes with rigor and provides specific, actionable feedback.

Scoring rubric (be honest and discerning — do NOT give every resume an 80+):
- overallScore: holistic 0-100 quality of the resume considering content, structure, achievements, clarity. Most real resumes score 50-75; only exceptional resumes exceed 85.
- atsScore: 0-100 representing how well an ATS would parse and match this resume against the job description. If no job description is provided, score against general ATS best practices (clear sections, standard fonts implied, no tables/columns indicators, contact info, dates, role titles).
- skillsMatchScore: 0-100. If a job description exists, this is the percentage of required skills the resume credibly demonstrates. If no JD, this represents skill breadth and depth signals from the resume.
- experienceScore: 0-100 representing the strength and relevance of work experience.
- experienceLevel: one of "entry" (0-2 yrs), "mid" (3-5 yrs), "senior" (6-10 yrs), "expert" (10+ yrs).
- yearsOfExperience: numeric estimate (use decimals if needed, e.g., 4.5).

Content rules:
- summary: 2-3 sentence professional summary of the candidate written for a hiring manager.
- strengths: 3-5 specific strengths grounded in the resume content (not generic).
- weaknesses: 3-5 honest gaps or weaknesses; if a JD exists, focus on misalignment with it.
- matchedSkills: skills present in the resume that match the job description (or are clearly valuable if no JD). Aim for 8-15.
- missingSkills: skills required/preferred by the JD that are absent (or commonly expected for this role type if no JD). Aim for 4-10.
- skillCategories: group all detected skills into 4-6 categories (e.g., "Languages", "Frameworks", "Cloud & DevOps", "Data", "Soft Skills"). Each category must have at least 1 skill.
- keywordHits: 8-15 important keywords from the JD (or expected for the role) and whether they appear in the resume, with the number of occurrences. If no JD, infer keywords from common expectations.
- improvements: 4-6 concrete, prioritized improvement suggestions. Each must include the actual current text from the resume (or a faithful paraphrase if exact text isn't available) and a stronger suggested rewrite. Mix priorities.
- atsBreakdown: 0-100 sub-scores for each ATS dimension. Be granular; these should not all equal atsScore.

Return ONLY the JSON object specified by the schema. No prose, no code fences.`;

export async function analyzeResume(params: {
  resumeText: string;
  jobDescription: string | null;
  candidateName: string | null;
  fileName: string;
}): Promise<AiAnalysis> {
  const { resumeText, jobDescription, candidateName, fileName } = params;

  const userPrompt = `Analyze the following resume${jobDescription ? " against the provided job description" : ""}.

${candidateName ? `Candidate label: ${candidateName}\n` : ""}File: ${fileName}

=== RESUME TEXT ===
${resumeText.slice(0, 18000)}
=== END RESUME ===

${
  jobDescription
    ? `=== JOB DESCRIPTION ===\n${jobDescription.slice(0, 6000)}\n=== END JOB DESCRIPTION ===`
    : "No job description was provided. Score the resume against general best practices and infer the most likely target role from its content."
}

Return the structured JSON analysis.`;

  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: [
      {
        role: "user",
        parts: [{ text: userPrompt }],
      },
    ],
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      responseMimeType: "application/json",
      responseSchema,
      maxOutputTokens: 8192,
      temperature: 0.4,
    },
  });

  const raw = response.text;
  if (!raw) {
    throw new Error("Gemini returned an empty response");
  }

  let parsed: AiAnalysis;
  try {
    parsed = JSON.parse(raw) as AiAnalysis;
  } catch (err) {
    throw new Error(`Gemini returned invalid JSON: ${(err as Error).message}`);
  }

  // Clamp scores defensively
  const clamp = (n: unknown): number => {
    const v = typeof n === "number" ? n : Number(n);
    if (!Number.isFinite(v)) return 0;
    return Math.max(0, Math.min(100, Math.round(v)));
  };

  return {
    overallScore: clamp(parsed.overallScore),
    atsScore: clamp(parsed.atsScore),
    skillsMatchScore: clamp(parsed.skillsMatchScore),
    experienceScore: clamp(parsed.experienceScore),
    experienceLevel: parsed.experienceLevel ?? "entry",
    yearsOfExperience:
      typeof parsed.yearsOfExperience === "number" && Number.isFinite(parsed.yearsOfExperience)
        ? Math.max(0, parsed.yearsOfExperience)
        : 0,
    summary: parsed.summary ?? "",
    strengths: parsed.strengths ?? [],
    weaknesses: parsed.weaknesses ?? [],
    matchedSkills: parsed.matchedSkills ?? [],
    missingSkills: parsed.missingSkills ?? [],
    skillCategories: parsed.skillCategories ?? [],
    keywordHits: parsed.keywordHits ?? [],
    improvements: parsed.improvements ?? [],
    atsBreakdown: {
      formatting: clamp(parsed.atsBreakdown?.formatting),
      keywords: clamp(parsed.atsBreakdown?.keywords),
      readability: clamp(parsed.atsBreakdown?.readability),
      sectionCoverage: clamp(parsed.atsBreakdown?.sectionCoverage),
      contactInfo: clamp(parsed.atsBreakdown?.contactInfo),
    },
  };
}
